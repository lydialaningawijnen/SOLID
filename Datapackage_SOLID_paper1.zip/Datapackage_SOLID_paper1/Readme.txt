This folder contains the syntaxes that are used for the first submission of the manuscript:
'The Longitudinal Role of Classroom Defending Norms in Victims� Psychological Adjustment, Causal Attributions, and Social Comparisons'
Authors: Lydia Laninga-Wijnen, Claire Garandeau, Sarah Malamut, Christina Salmivalli.

The pre-registration of study hypotheses and analyses can be found here:
https://aspredicted.org/c62ga.pdf

The transparant changes to analyses can be found here:
FILL IN


All syntaxes including the produced output are organized per table or appendix.

Pseudonymized data can be retrieved from the first author: lalawi@utu.fi