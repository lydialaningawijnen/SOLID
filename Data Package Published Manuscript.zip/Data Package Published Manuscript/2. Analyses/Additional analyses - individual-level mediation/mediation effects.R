#########################################################
## R-script for estimating bootstrapped mediation effects
#########################################################

## Lydia Laninga-Wijnen
## 27.3.2022

#TABLE A3 NOTE

#The role of bully-oriented defending norms in victims self-esteem: explained by self-blame?
a0 = .280 # B of bully-oriented defending norms * victimization on self-blame
a0std = 0.234 # SE of bully-oriented defending norms * victimization on self-blame
a1 = -.128 # B of self-esteem on self-blame
a1std = 0.016
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

#TABLE A3 NOTE.
#The role of bully-oriented defending norms in victims depression: explained by self-blame?
a0 = .346 # B of bully-oriented defending norms * victimization on self-blame
a0std = 0.239 # SE of bully-oriented defending norms * victimization on self-blame
a1 = .077 # B of depression on self-blame
a1std = 0.012 # SE of depression on self-blame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

#TABLE A4 NOTE
#The role of bully-oriented defending norms in victims self-esteem: explained by upward comparisons?
a0 = .150 # B of bully-oriented defending norms * victimization on social comparisons
a0std = 0.167 # SE of bully-oriented defending norms * victimization on social comparisons
a1 = -.214 # B of selfesteem regressed on social comparisons
a1std = 0.022 # SE of selfesteem regressed on social comparisons
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


#TABLE A4 NOTE
#The role of bully-oriented defending norms in victims depression: explained by upward comparisons?
a0 = .153 # B of bully-oriented defending norms * victimization on social comparisons
a0std = 0.164 # SE of bully-oriented defending norms * victimization on social comparisons
a1 = .098 # B of depression on social comparisons
a1std = 0.017 # SE of depression on social comparisons
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

#Table A1 Stable victims.
#The role of norms in stable victims selfesteem through selfblame
a0 = 1.212 # B of self-blame regressed on norms
a0std = 0.604 # SE of self-blame regressed on norms
a1 = -.096 # B of selfesteem regressed on selfblame
a1std = 0.076 # SE of selfesteem regressed on selfblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)



#The role of norms in stable victims selfesteem through bullyblame
a0 = -.482 # B of bully-blame regressed on norms
a0std = 0.516 # SE of bully-blame regressed on norms
a1 = .166 # B of selfesteem regressed on bullyblame
a1std = 0.089 # SE of selfesteem regressed on bullyblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


#Table A1 Stable victims.
#The role of norms in stable victims depression through selfblame
a0 = 1.234 # B of self-blame regressed on norms
a0std = 0.608 # SE of self-blame regressed on norms
a1 = -.001 # B of depression regressed on selfblame
a1std = 0.095 # SE of depression regressed on selfblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

#Table A1 Stable victims.
#The role of norms in stable victims' depression through bullyblame
a0 = 1.234 # B of self-blame regressed on norms
a0std = 0.608 # SE of self-blame regressed on norms
a1 = -.062 # B of depression regressed on bullyblame
a1std = 0.122 # SE of depression regressed on bullyblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

#####################################################
#additional analyses, reported in the results section.
#####################################################

## Individual-level mediation
#for this, I used the output "additional_individual_mediation_sbblame_se_3470students.out"
#The role of norms in stable victims' selfest through selfblame
a0 = .099 # B of self-blame regressed on victimization
a0std = 0.030 # SE of self-blame regressed on victimization
a1 = -.136 # B of selfesteem regressed on selfblame
a1std = 0.016 # SE of selfesteem regressed on selfblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


## Individual-level mediation
#for this, I used the output "additional_individual_mediation_sbblame_se_3470students.out"
#The role of norms in stable victims' selfest through bullyblame
a0 = .057 # B of bully-blame regressed on victimization
a0std = 0.020 # SE of bully-blame regressed on victimization
a1 = -.016 # B of selfesteem regressed on bullyblame
a1std = 0.017 # SE of selfesteem regressed on bullyblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


#############

## Individual-level mediation
#for this, I used the output "additional_individual_mediation_sbblame_cdi_3470students.out"
#The role of norms in stable victims' depr through selfblame. depression = cdi.
a0 = .099 # B of self-blame regressed on victimization
a0std = 0.030 # SE of self-blame regressed on victimization
a1 = .082 # B of depr regressed on selfblame
a1std = 0.012 # SE of depr regressed on selfblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


## Individual-level mediation
#for this, I used the output "additional_individual_mediation_sbblame_cdi_3470students.out"
#The role of norms in stable victims' depr through bullyblame
a0 = .057 # B of bully-blame regressed on victimization
a0std = 0.020 # SE of bully-blame regressed on victimization
a1 = -.010 # B of depr regressed on bullyblame
a1std = 0.013 # SE of depr regressed on bullyblame
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)


### now for social comparisons.

## Individual-level mediation depression
#for this, I used the output "additional_individual_mediation_scomp_cdi_3470students.out"
#The role of norms in stable victims' depr through social comparisons. depression = cdi.
a0 = .021 # B of soc. comp regressed on victimization
a0std = 0.028 # SE of soc. comp regressed on victimization
a1 = .089 # B of depr regressed on soc. comp
a1std = 0.018 # SE of depr regressed on soc. comp
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

## Individual-level mediation selfesteem
#for this, I used the output "additional_individual_mediation_scomp_se_3470students.out"
#The role of norms in stable victims' self-esteem through social comparisons. 
a0 = .021 # B of soc. comp regressed on victimization
a0std = 0.028 # SE of soc. comp regressed on victimization
a1 = -.207 # B of selfest regressed on soc. comp
a1std = 0.022 # SE of selfest regressed on soc. comp
rep = 20000
conf = 95
a0vec = rnorm(rep) * a0std + a0
a1vec = rnorm(rep) * a1std + a1
ind = a0vec * a1vec
low = (1-conf/100)/2
upp = (1-conf/100)/2 + (conf/100)
mean(ind)
LL = quantile(ind,low)
UL = quantile(ind,upp)
LL4 = format(LL, digits = 5) 
UL4 = format(UL, digits = 5) 

UL4
LL4
mean(ind)

