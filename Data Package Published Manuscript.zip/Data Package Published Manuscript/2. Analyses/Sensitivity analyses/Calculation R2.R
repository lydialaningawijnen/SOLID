#the variance of random slope of RI model minus the variance of the slope in the CLI model, divided by variance around slope of RI model.
(.031-.027)/.031
(.011-.010)/.011
